	import java.io.*;
	import java.util.Scanner;
	import java.util.InputMismatchException;
	import java.util.Random;
public class YG2017400018 {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner console = new Scanner(System.in);
		String cevap = "Y";
		System.out.println("Welcome to the XOX Game.");
		System.out.println("Would you like to load the board from file or create a new one? (L or C)");
		String a = console.next().toLowerCase(); 
		while(!a.equals("c") && !a.equals("l")) {
			System.out.println(" (L or C)");
			a = console.next().toLowerCase();
		}
		String filename = "";
		if (a.equals("l")) {
			System.out.print("Please enter the file name:");
			filename = console.nextLine();
			while (!isCorrect(filename)) {
				System.out.print("Please enter the file name:");
				filename = console.nextLine();
			}

		}
		System.out.println("Enter your symbol: (X or O)");
		char b = console.next().toUpperCase().charAt(0);
		while(b!='X' && b!='O') {
			System.out.println(" (X or O)");
			b = console.next().toUpperCase().charAt(0);
		}
		char z = ' ';
		if (b == ('X')) {
			z = 'O';
		} else if (b == ('O')) {
			z = 'X';
		}
		int countuser = 0;
		int countcomputer = 0;
		int n = 5;
		String s=table(z, a, filename, b);
		while (cevap.equals("Y")) {
			n = finalMethod(s,a, z, b, filename);
			if (n == 1) {
				countuser++;
			} else if (n == 2) {
				countcomputer++;
			}
			cevap = console.next().toUpperCase(); // answer to "Do you want to play again?"
			while (!cevap.equals("N") && !cevap.equals("Y")) {
				System.out.print("Do you want to play again?(Y or N)");
				cevap = console.next();
			}
			s="EEEEEEEEEEEEEEEE";
			
		}
		System.out.println("You: " + countuser + " Computer: " + countcomputer);
		System.out.println("Thanks for playing.");

	}

	public static String table(char z, String a, String filename, char b) throws FileNotFoundException {
		Scanner console = new Scanner(System.in);
		Random random = new Random();
		String s = "";
		int d = 0;
		int e = 0;
		if (a.equals("l")) {  //answer to "Would you like to load the board from file or create a new one? (L or C)"
			File fil = new File(filename);
			Scanner scan = new Scanner(fil);

			s = scan.nextLine();
			int countb = 0;
			int counte = 0;
			int countz = 0;
			for (int i = 0; i < 16; i++) {
				if (s.charAt(i) == b) {
					countb++;
				}
				if (s.charAt(i) == z) {
					countz++;
				}
				if (s.charAt(i) == 'E') {
					counte++;
				}
			}
			if (countz > countb) {
				System.out.println("You will start:");
				return s;
			} else if (countb > countz) {
				System.out.println("Computer will start:");
				d = random.nextInt(4) + 1;
				e = random.nextInt(4) + 1;

				int h = (d - 1) * 4 + (e - 1);
				while (s.charAt(h) != 'E') {
					d = random.nextInt(4) + 1;
					e = random.nextInt(4) + 1;
					h = (d - 1) * 4 + (e - 1);
				}
				s = s.substring(0, h) + z + s.substring(h + 1, 16);
				return s;
			} else if (countb == countz) {
				int c = random.nextInt(2);
				if (c == 0) {
					System.out.println("You will start:");
					return s;
				} else if (c == 1) {
					System.out.println("Computer will start:");
					d = random.nextInt(4) + 1;
					e = random.nextInt(4) + 1;

					int h = (d - 1) * 4 + (e - 1);
					while (s.charAt(h) != 'E') {
						d = random.nextInt(4) + 1;
						e = random.nextInt(4) + 1;
						h = (d - 1) * 4 + (e - 1);
					}
					s = s.substring(0, h) + z + s.substring(h + 1, 16);
					return s;
				}
			}
		} 
		else if (a.equals("c")) { //answer to "Would you like to load the board from file or create a new one? (L or C)"
			s = "EEEEEEEEEEEEEEEE";
			int c = random.nextInt(2); // random for whose is the first attack

			if (c == 0) {
				System.out.println("You will start:");
				return s;
			} else if (c == 1) {
				System.out.println("Computer will start:");
				d = random.nextInt(4) + 1;
				e = random.nextInt(4) + 1;

				int h = (d - 1) * 4 + (e - 1);

				s = s.substring(0, h) + z + s.substring(h + 1, 16);
				return s;
			}
		}
		return s; // end of this method user's turn.
	}
	public static void table1(String s) {
		String s1 = "";
		String s2 = "";
		String s3 = "";
		String s4 = "";

		for (int i = 0; i < s.length(); i++) { // this for loop provides lines seperately according to String s (board string)
			if (i < 4)
				s1 = s1 + "| " + s.charAt(i) + " | ";
			else if (i >= 4 && i < 8)
				s2 = s2 + "| " + s.charAt(i) + " | ";
			else if (i >= 8 && i < 12)
				s3 = s3 + "| " + s.charAt(i) + " | ";
			else if (i >= 12 && i < 16)
				s4 = s4 + "| " + s.charAt(i) + " | ";
		}
		System.out.println(s1+"\n"+s2+"\n"+s3+"\n"+s4);
		 
		// this method is used in order to print board.
	}
	public static boolean isEndGame(String s) throws FileNotFoundException {
		//isEndGame controls the string s for decide if game is over except tie
		// horizontal control
		int p = 0;
		while (p < 4) {
			if (s.charAt(4 * p) == s.charAt(4 * p + 1) && s.charAt(4 * p + 1) == s.charAt(4 * p + 2)
					&& s.charAt(4 * p) != 'E') {
				return true;
			}
			if (s.charAt(4 * p + 1) == s.charAt(4 * p + 2) && s.charAt(4 * p + 2) == s.charAt(4 * p + 3)
					&& s.charAt(4 * p + 1) != 'E') {
				return true;
			}
			p++;
		}
		// vertical control
		int v = 0;
		while (v < 8) {
			if (s.charAt(v) == s.charAt(v + 4) && s.charAt(v + 4) == s.charAt(v + 8) && s.charAt(v) != 'E') {
				return true;
			}
			v++;
		}
		// diagonal control
		for (int k = 0; k < 2; k++) {
			if (s.charAt(k) == s.charAt(k + 5) && s.charAt(k + 5) == s.charAt(k + 10) && s.charAt(k) != 'E') {
				return true;
			}
		}
		for (int j = 2; j <= 3; j++) {
			if (s.charAt(j) == s.charAt(j + 3) && s.charAt(j + 3) == s.charAt(j + 6) && s.charAt(j) != 'E') {
				return true;
			}
		}
		for (int f = 4; f <= 5; f++) {
			if (s.charAt(f) == s.charAt(f + 5) && s.charAt(f + 5) == s.charAt(f + 10) && s.charAt(f) != 'E') {
				return true;
			}
		}
		for (int z = 6; z <= 7; z++) {
			if (s.charAt(z) == s.charAt(z + 3) && s.charAt(z + 3) == s.charAt(z + 6) && s.charAt(z) != 'E') {
				return true;
			}
		}
		return false;
	}
	public static boolean isTie(String s) {
		// this method controls the board for decide if game is over in tie by looking empty cells.
		// if there is no empty cell and nobody wins,game is over in tie.
		if (s.indexOf('E') == -1) {
			return true;
		}
		return false;
	}
	public static boolean isCorrect(String filename) throws FileNotFoundException {
		//if user wants to load the board from file,the file must be controlled.
		//This method controls the file in terms of existence ,length,number of X's,O's and E's		
		File fil = new File(filename);
		if (!fil.exists()) {
			return false;
		}
		Scanner scan = new Scanner(fil);
		String s = scan.next();
		if (s.length() != 16) {
			return false;
		}
		int countx = 0;
		int counte = 0;
		int counto = 0;
		for (int i = 0; i < 16; i++) {
			if (s.charAt(i) == 'X') {
				countx++;
			}
			if (s.charAt(i) == 'O') {
				counto++;
			}
			if (s.charAt(i) == 'E') {
				counte++;
			}
		}
		if (counto + counte + countx != 16) {
			return false;
		}
		if (Math.abs(counto - countx) > 1) {
			return false;
		}
		if (isEndGame(s) == true || isTie(s) == true) {
			return false;
		}
		return true;
	}

	public static String gaming(String s, char b) {
		//This method returns board after user's attack according to coordinates which are input from user.
		Scanner console = new Scanner(System.in);
		System.out.print("Enter coordinates:");
		int d = 0;
		int e = 0;
		int h = 0;
		while (true) {
			try {                 //in case of Strings
				Scanner console2 = new Scanner(System.in);
				d = console2.nextInt();
				e = console2.nextInt();
			} catch (InputMismatchException r) {
				System.out.print("Wrong input! Try again:");
				continue;
			}
			break;
		}
		h = (d - 1) * 4 + (e - 1); //location of coordinates in board
		while (e < 1 || e > 4 || d < 1 || d > 4) { //in case of coordinates out of board
			System.out.print("Wrong input! Try again:");
			while (true) {
				try {
					Scanner console2 = new Scanner(System.in);
					d = console2.nextInt();
					e = console2.nextInt();
				} catch (InputMismatchException r) {
					System.out.print("Wrong input! Try again:");
					continue;
				}
				break;
			}
			h = (d - 1) * 4 + (e - 1);
		}
		while (s.charAt(h) != 'E') {

			System.out.print("Wrong input! Try again:");

			while (true) {
				try {
					Scanner console2 = new Scanner(System.in);
					d = console2.nextInt();
					e = console2.nextInt();
				} catch (InputMismatchException r) {
					System.out.print("Wrong input! Try again:");
					continue;
				}
				break;
			}
			h = (d - 1) * 4 + (e - 1);
		}
		s = s.substring(0, h) + b + s.substring(h + 1); 
		return s;
	}
	public static String gamingcomputer(String s, char z) {
		//This method returns board string (s) after computer's attack which is random.
 		Random random = new Random();

		int d = random.nextInt(4) + 1;
		int e = random.nextInt(4) + 1;

		int h = (d - 1) * 4 + (e - 1);

		while (s.charAt(h) != 'E') {
			d = random.nextInt(4) + 1;
			e = random.nextInt(4) + 1;
			h = (d - 1) * 4 + (e - 1);
		}
		s = s.substring(0, h) + z + s.substring(h + 1);
		return s;
	}
	public static int finalMethod(String s,String a, char z, char b, String filename) throws FileNotFoundException {
				//finalMethod represents sequence of methods in one game.
				//char z:symbol of computer
				//char b:symbol of user
		
		table1(s);
		
		while (isEndGame(s) == false) {
			s = gaming(s, b);
			if (isEndGame(s) == true) {
				table1(s);
				System.out.println("You win!Dou you want to play again?(Y or N)");				
				return 1;
			}
			if(isTie(s)==true) {
				System.out.println("Game over in tie!Dou you want to play again?(Y or N)");
				return 0;
			}
			s = gamingcomputer(s, z);
			table1(s);
			if (isEndGame(s) == true) {
				System.out.print("Computer wins!Do you want to play again?(Y or N)");
				return 2;
			}
			if(isTie(s)==true) {
				System.out.println("Game over in tie!Dou you want to play again?(Y or N)");
				return 0;
			}			
		}
		return 5; //it is a random number
	}	
	
}
